package com.example.Shopping.Mall.Management.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name="item")
@Entity
public class Item {
	
	@Id
   public int itemId;
   public String itemName;
   public float itemPrice;
  
   public int getItemId() {
	return itemId;
   }
   public void setItemId(int itemId) {
	this.itemId = itemId;
   }
   public String getItemName() {
	return itemName;
   }
   public void setItemName(String itemName) {
	this.itemName = itemName;
   }
   public float getItemPrice() {
	return itemPrice;
   }
   public void setItemPrice(float itemPrice) {
	this.itemPrice = itemPrice;
   }
   
}
