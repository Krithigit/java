package com.example.Shopping.Mall.Management.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Shopping.Mall.Management.entity.Item;

public interface ItemRepo extends JpaRepository<Item,Integer>{

}
