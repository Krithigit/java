package com.example.Shopping.Mall.Management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Shopping.Mall.Management.entity.Item;
import com.example.Shopping.Mall.Management.service.ItemService;

//controller class communicates with postman
//postman->controller->service->repository->database
@RestController
public class AlController {
	
	@Autowired
	public ItemService alser;
    
	//insert
	@PostMapping("/additem")
	public Item addItem(@RequestBody Item al) { 
		return alser.addItem(al );
	}
	//Get
		@GetMapping("/getitem")
		public List<Item> getItem() { 
			return alser.getItem();
		}
		//delete
				@DeleteMapping("/deleteitem/{al}")
				public void deleteItem(@PathVariable int al) { 
					alser.deleteAl(al);
				}
}
